<br/>
<div align="center">

  # Proxyless Spotify Follow Bot
  Requests based multi-threaded script for increasing followers on Spotify. Click <a href="https://github.com/useragents/Proxyless-Spotify-Follow-Bot/issues">here</a> to report bugs.
  
  ![image](https://user-images.githubusercontent.com/102762968/161622560-22f88eae-709e-4c07-a66e-8147dd3d43dd.png)

</div>

--------------------------------------

### Usage

1. Download ZIP <a href="https://github.com/useragents/Proxyless-Spotify-Follow-Bot/archive/refs/heads/main.zip">here</a> and extract the ZIP 
2. Install <a href="https://github.com/useragents/Instagram-Username-Auto-Claimer/blob/main/requirements.txt">requirements.txt</a> by typing `pip install -r requirements.txt` in Command Prompt
3. Open the `main.py` in a text editor or other and replace the `spotify_profile` variable's value with your Spotify username/link.
4. Run the `main.py` file and enter the amount of threads

--------------------------------------

### Please note

This script was made for educational purposes, I am not responsible for your actions using this script. This script was made for educational purposes.
